# CortexLinuxAI Discord Bot

A production-ready Discord bot powered by Claude API with **RAG**, **conversation memory**, and **slash commands** - designed to help users with Cortex Linux, the world's first AI-Native Operating System.

## Features

### For Everyone
- **Slash Commands** - Professional Discord UX (`/cortex ask`, `/cortex install`, etc.)
- **Rich Embeds** - Beautiful formatted responses with colors and buttons
- **Conversation Memory** - Remembers context within threads (30-min TTL)
- **Auto-Threading** - Creates threads for long conversations
- **Feedback Buttons** - Rate responses with 👍/👎

### For Beginners
- **Interactive Install Guide** - Step-by-step with navigation buttons
- **Skill Detection** - Adapts response complexity to your level
- **Error Explainer** - Paste errors, get human-friendly fixes

### For Developers
- **GitHub Search** - Search issues/PRs directly from Discord
- **RAG System** - Real-time docs from GitHub and website
- **Debug Command** - Analyzes errors and finds related issues

## Commands

### Slash Commands
| Command | Description |
|---------|-------------|
| `/cortex ask <question>` | Ask any question (option to create thread) |
| `/cortex install` | Interactive installation guide |
| `/cortex debug <error>` | Analyze an error message |
| `/cortex search <query>` | Search GitHub issues/PRs |
| `/cortex issue <number>` | Get details on specific issue |
| `/cortex help` | Show all commands |

### Text Commands (mention bot)
| Command | Description |
|---------|-------------|
| `@Bot <question>` | Ask a question |
| `@Bot !refresh` | Refresh knowledge base |
| `@Bot !clear` | Clear conversation memory |
| `@Bot !stats` | Show bot statistics |

## Requirements

- Node.js 18+
- Discord Bot Token
- Anthropic API Key
- GitHub Token (optional, for full RAG)

## Setup

### 1. Clone and Install

```bash
git clone https://github.com/cortexlinux/discord-claude-bot
cd discord-claude-bot
npm install
```

### 2. Create Discord Bot

1. Go to [Discord Developer Portal](https://discord.com/developers/applications)
2. Create a new application
3. Go to "Bot" section and create a bot
4. Enable these Privileged Gateway Intents:
   - Message Content Intent
   - Server Members Intent (optional)
5. Copy the bot token

### 3. Generate Bot Invite Link

In the Developer Portal:
1. Go to "OAuth2" > "URL Generator"
2. Select scopes: `bot`, `applications.commands`
3. Select permissions:
   - Read Messages/View Channels
   - Send Messages
   - Read Message History
   - Create Public Threads
   - Send Messages in Threads
   - Embed Links
   - Use Slash Commands
4. Copy and use the generated URL to invite the bot

### 4. Get API Keys

**Anthropic API Key:**
1. Go to [Anthropic Console](https://console.anthropic.com/)
2. Create an API key

**GitHub Token (Recommended):**
1. Go to [GitHub Settings > Tokens](https://github.com/settings/tokens)
2. Create a token with `public_repo` scope
3. This enables full RAG with all 500+ doc chunks

### 5. Configure Environment

```bash
cp .env.example .env
```

Edit `.env`:

```env
DISCORD_TOKEN=your_discord_bot_token
ANTHROPIC_API_KEY=your_anthropic_api_key
GITHUB_TOKEN=your_github_token          # Optional but recommended
GUILD_ID=your_server_id                  # Optional, for instant command registration
```

### 6. Run the Bot

```bash
npm start
```

For development with auto-reload:

```bash
npm run dev
```

## Architecture

```
discord-claude-bot/
├── src/
│   ├── index.js                 # Main entry point
│   ├── commands/
│   │   └── slashCommands.js     # Slash command definitions & handlers
│   ├── llm/
│   │   └── claude.js            # Claude API client with RAG
│   ├── memory/
│   │   └── conversationMemory.js # Multi-turn conversation memory
│   ├── rag/
│   │   ├── knowledgeBase.js     # In-memory document store
│   │   ├── retriever.js         # GitHub/website content fetcher
│   │   └── githubSearch.js      # GitHub issues/PR search
│   └── utils/
│       ├── dailyLimit.js        # Rate limiting (5 questions/day)
│       ├── embeds.js            # Rich embed templates
│       ├── shouldRespond.js     # Mention/reply detection
│       └── splitMessage.js      # Message chunking for Discord
├── .env.example
├── package.json
└── README.md
```

## RAG System

The bot uses Retrieval-Augmented Generation:

1. **On startup**: Fetches README, docs, releases from GitHub + website
2. **Per question**: Retrieves top 5 relevant chunks via keyword matching
3. **For errors**: Also searches GitHub issues for related problems
4. **Auto-refresh**: Knowledge base updates every 30 minutes

Without `GITHUB_TOKEN`: ~70 chunks (rate limited)
With `GITHUB_TOKEN`: ~600 chunks (full knowledge)

## Conversation Memory

- Maintains context per user/thread for 30 minutes
- Stores last 10 messages per conversation
- Auto-creates threads for complex questions
- Use `!clear` to reset memory

## License

Apache-2.0
